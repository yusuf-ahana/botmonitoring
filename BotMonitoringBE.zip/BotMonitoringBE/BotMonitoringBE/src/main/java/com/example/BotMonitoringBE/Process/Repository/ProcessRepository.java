package com.example.BotMonitoringBE.Process.Repository;

import com.example.BotMonitoringBE.Process.Model.ProcessModel;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ProcessRepository extends MongoRepository<ProcessModel,String> {
}
