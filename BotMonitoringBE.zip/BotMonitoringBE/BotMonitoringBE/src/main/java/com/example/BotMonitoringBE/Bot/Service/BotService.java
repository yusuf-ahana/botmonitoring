package com.example.BotMonitoringBE.Bot.Service;


import com.example.BotMonitoringBE.Bot.Model.BotModel;
import com.example.BotMonitoringBE.Bot.Repository.BotRepository;
import org.apache.juli.logging.Log;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BotService {


    @Autowired
    private BotRepository botRepository;

    public BotModel addBot(BotModel botModel)
    {
        return botRepository.save(botModel);
    }

//    public BotModel updateBot(BotModel botModel)
//    {
//       BotModel existingBot=botRepository.findById(botModel.getBotId())
//          .orElseThrow(() -> new CustomException("Bot ID " + botModel.getBotId() + " not found."));
//       existingBot.setBotName(botModel.getBotName());
//       existingBot.setHostName(botModel.getHostName());
//       existingBot.setIPAddress(botModel.getIPAddress());
//       existingBot.setUIPathVersion(botModel.getUIPathVersion());
//
//       return botRepository.save(existingBot);
//
//
//    }

    public List<BotModel> getAllBot()
    {
        return botRepository.findAll();
    }

//    public String deleteBot(Long botId)
//    {
//          botRepository.existsById(botId)
//                  .orElseThrow(() -> new CustomException("Bot ID " + botId + " not found."));
//          botRepository.deleteById(botId);
//          return "Bot Deleted";
//
//    }


}
