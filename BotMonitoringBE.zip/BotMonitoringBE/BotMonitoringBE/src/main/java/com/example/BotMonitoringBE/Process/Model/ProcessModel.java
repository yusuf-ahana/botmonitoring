package com.example.BotMonitoringBE.Process.Model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import java.util.Date;
import java.util.List;

@Document(collection = "process")
public class ProcessModel {

    @Id
    private String processId;

    @Field(name = "botId")
    private String botId;

    @Field(name = "processName")
    private String processName;

    @Field(name = "productionMovedDate")
    private Date productionMovedDate;

    @Field(name = "softwareInstalled")
    private String softwareInstalled;

    @Field(name = "ownerDetails")
    private Owner owner;

    @Field(name = "teamMembers")
    private List<TeamMember> teamMembers; // Array of team members

    public ProcessModel() {}

    public ProcessModel(String botId, String processName, Date productionMovedDate, String softwareInstalled, Owner owner, List<TeamMember> teamMembers) {
        this.botId = botId;
        this.processName = processName;
        this.productionMovedDate = productionMovedDate;
        this.softwareInstalled = softwareInstalled;
        this.owner = owner;
        this.teamMembers = teamMembers;
    }

    // Getters and Setters
    public String getProcessId() {
        return processId;
    }


    public void setProcessId(String processId) {
        this.processId = processId;
    }

    public String getBotId() {
        return botId;
    }

    public void setBotId(String botId) {
        this.botId = botId;
    }

    public String getProcessName() {
        return processName;
    }

    public void setProcessName(String processName) {
        this.processName = processName;
    }

    public Date getProductionMovedDate() {
        return productionMovedDate;
    }

    public void setProductionMovedDate(Date productionMovedDate) {
        this.productionMovedDate = productionMovedDate;
    }

    public String getSoftwareInstalled() {
        return softwareInstalled;
    }

    public void setSoftwareInstalled(String softwareInstalled) {
        this.softwareInstalled = softwareInstalled;
    }

    public Owner getOwner() {
        return owner;
    }

    public void setOwner(Owner owner) {
        this.owner = owner;
    }

    public List<TeamMember> getTeamMembers() {
        return teamMembers;
    }

    public void setTeamMembers(List<TeamMember> teamMembers) {
        this.teamMembers = teamMembers;
    }
}
