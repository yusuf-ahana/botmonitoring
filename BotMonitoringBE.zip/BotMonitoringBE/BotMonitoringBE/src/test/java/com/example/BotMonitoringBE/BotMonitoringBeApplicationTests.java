package com.example.BotMonitoringBE;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BotMonitoringBeApplicationTests {

	@Test
	void contextLoads() {
	}

}
