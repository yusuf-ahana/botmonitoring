package com.example.BotMonitoringBE.Error;

public class CustomException extends RuntimeException {
    public CustomException(String message) {
        super(message);
    }
}
