package com.example.BotMonitoringBE.Bot.Controller;

import com.example.BotMonitoringBE.Bot.Model.BotModel;
import com.example.BotMonitoringBE.Bot.Service.BotService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/bot")
public class BotController {

    @Autowired
    private BotService botService;

    @PostMapping("/addBot")
    public BotModel addBot(@RequestBody BotModel botModel)
    {
        return botService.addBot(botModel);
    }
//
//    @PostMapping("/updateBot")
//    public BotModel updateBot(@RequestBody BotModel botModel)
//
//    {
//        return botService.updateBot(botModel);
//    }

    @GetMapping("/getAllBot")
    public List<BotModel> getAllBot()
    {
        return botService.getAllBot();
    }

}
