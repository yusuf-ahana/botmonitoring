package com.example.BotMonitoringBE.Process.Model;

public class TeamMember {

    private String name;          // Team member's name
    private String phoneNumber;   // Team member's phone number
    private String email;         // Team member's email

    public TeamMember() {}

    public TeamMember(String name, String phoneNumber, String email) {
        this.name = name;
        this.phoneNumber = phoneNumber;
        this.email = email;
    }

    // Getters and Setters
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}