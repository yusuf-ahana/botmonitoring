package com.example.BotMonitoringBE.Process.Controller;

import com.example.BotMonitoringBE.Bot.Model.BotModel;
import com.example.BotMonitoringBE.Process.Model.ProcessModel;
import com.example.BotMonitoringBE.Process.Service.ProcessService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/process")
public class ProcessController {

    @Autowired
    private ProcessService processService;

    @PostMapping("/addProcess")
    public ProcessModel addProcess(@RequestBody ProcessModel processModel)
    {
        return processService.saveProcess(processModel);
    }

//    @PostMapping("/updateProcess")
//    public ProcessModel updateProcess(@RequestBody ProcessModel processModel)
//
//    {
//        return processService.updateProcess(processModel);
//    }

    @GetMapping("/getAllProcess")
    public List<ProcessModel> getAllProcess()
    {
        return botService.getAllBot();
    }
}
