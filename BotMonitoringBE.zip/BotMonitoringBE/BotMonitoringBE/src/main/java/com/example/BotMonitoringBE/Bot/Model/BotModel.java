package com.example.BotMonitoringBE.Bot.Model;


import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import java.util.Date;

@Document(collection = "bot") // MongoDB collection name
public class BotModel {

    @Id
    private String botId; // MongoDB uses String IDs (ObjectId by default)

    @Field(name = "botName")
    private String botName;

    @Field(name = "ipAddress")
    private Long ipAddress;

    @Field(name = "hostName")
    private String hostName;

    @Field(name = "uiPathVersion")
    private Long uiPathVersion;

    @Field(name = "licenceType")
    private String licenceType;

    @Field(name = "licenceKey")
    private String licenceKey;

    @Field(name = "licenceStartDate")
    private Date licenceStartDate;

    @Field(name = "licenceEndDate")
    private Date licenceEndDate;

    @Field(name = "softwareInstalled")
    private String softwareInstalled;

    @Field(name = "machineName")
    private String machineName;

    public BotModel() {}

    public BotModel(String botName, Long ipAddress, String hostName, Long uiPathVersion, String licenceType, String licenceKey, Date licenceStartDate, Date licenceEndDate, String softwareInstalled, String machineName) {
        this.botName = botName;
        this.ipAddress = ipAddress;
        this.hostName = hostName;
        this.uiPathVersion = uiPathVersion;
        this.licenceType = licenceType;
        this.licenceKey = licenceKey;
        this.licenceStartDate = licenceStartDate;
        this.licenceEndDate = licenceEndDate;
        this.softwareInstalled = softwareInstalled;
        this.machineName = machineName;
    }

    // Getters and Setters
    public String getBotId() {
        return botId;
    }

    public void setBotId(String botId) {
        this.botId = botId;
    }

    public String getBotName() {
        return botName;
    }

    public void setBotName(String botName) {
        this.botName = botName;
    }

    public Long getIpAddress() {
        return ipAddress;
    }

    public void setIpAddress(Long ipAddress) {
        this.ipAddress = ipAddress;
    }

    public String getHostName() {
        return hostName;
    }

    public void setHostName(String hostName) {
        this.hostName = hostName;
    }

    public Long getUiPathVersion() {
        return uiPathVersion;
    }

    public void setUiPathVersion(Long uiPathVersion) {
        this.uiPathVersion = uiPathVersion;
    }

    public String getLicenceType() {
        return licenceType;
    }

    public void setLicenceType(String licenceType) {
        this.licenceType = licenceType;
    }

    public String getLicenceKey() {
        return licenceKey;
    }

    public void setLicenceKey(String licenceKey) {
        this.licenceKey = licenceKey;
    }

    public Date getLicenceStartDate() {
        return licenceStartDate;
    }

    public void setLicenceStartDate(Date licenceStartDate) {
        this.licenceStartDate = licenceStartDate;
    }

    public Date getLicenceEndDate() {
        return licenceEndDate;
    }

    public void setLicenceEndDate(Date licenceEndDate) {
        this.licenceEndDate = licenceEndDate;
    }

    public String getSoftwareInstalled() {
        return softwareInstalled;
    }

    public void setSoftwareInstalled(String softwareInstalled) {
        this.softwareInstalled = softwareInstalled;
    }

    public String getMachineName() {
        return machineName;
    }

    public void setMachineName(String machineName) {
        this.machineName = machineName;
    }
}