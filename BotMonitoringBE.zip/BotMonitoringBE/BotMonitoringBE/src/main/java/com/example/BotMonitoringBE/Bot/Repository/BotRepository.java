package com.example.BotMonitoringBE.Bot.Repository;

import com.example.BotMonitoringBE.Bot.Model.BotModel;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface BotRepository extends MongoRepository<BotModel,String> {
}
