package com.example.BotMonitoringBE.Process.Service;

import com.example.BotMonitoringBE.Process.Model.ProcessModel;
import com.example.BotMonitoringBE.Process.Repository.ProcessRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProcessService {

    @Autowired
    private ProcessRepository processRepository;

    public ProcessModel saveProcess(ProcessModel processModel)
    {
       return  processRepository.save(processModel);
    }

//    public ProcessModel updateProcess(ProcessModel processModel)
//    {
//        ProcessModel existingProcess=processRepository.findById(processModel.getProcessId())
//                .orElseThrow(() -> new CustomException("Process ID " + processModel.getProcessId() + " not found."));
//
//        existingProcess.setBotId(processModel.getBotId());
//        existingProcess.setProcessName(processModel.getProcessName());
//        return processRepository.save(existingProcess);
//    }

    public List<ProcessModel> getAllProcess()
    {
        return processRepository.findAll();
    }


}
