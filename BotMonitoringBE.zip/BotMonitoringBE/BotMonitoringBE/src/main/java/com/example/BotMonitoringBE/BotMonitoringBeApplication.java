package com.example.BotMonitoringBE;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BotMonitoringBeApplication {

	public static void main(String[] args) {
		SpringApplication.run(BotMonitoringBeApplication.class, args);
	}

}
